
const { gql, GraphQLClient } = require('graphql-request');
const { Connection, PublicKey } = require('@solana/web3.js');

// Shyft API configuration
const shyftApiKey = process.env.SHYFT_API_KEY || 'zeEVxN5d6lQsWBD_';
const gqlEndpoint = `https://programs.shyft.to/v0/graphql/?api_key=${shyftApiKey}`;
const rpcEndpoint = `https://rpc.shyft.to/?api_key=${shyftApiKey}`;

const graphQLClient = new GraphQLClient(gqlEndpoint, {
  method: 'POST',
  jsonSerializer: {
    parse: JSON.parse,
    stringify: JSON.stringify,
  },
});

const connection = new Connection(rpcEndpoint);

// Fetch liquidity pool information by token mint
async function queryLpByToken(tokenMint) {
  const query = gql`
    query MyQuery($where: Raydium_LiquidityPoolv4_bool_exp) {
      Raydium_LiquidityPoolv4(
        where: $where
      ) {
        lpMint
        lpReserve
        baseMint
        quoteMint
      }
    }`;

  const variables = {
    where: {
      _or: [
        { baseMint: { _eq: tokenMint } },
        { quoteMint: { _eq: tokenMint } },
      ],
    },
  };

  return await graphQLClient.request(query, variables);
}

// Function to calculate burn percentage
function getBurnPercentage(lpReserve, actualSupply) {
  const maxLpSupply = Math.max(actualSupply, (lpReserve - 1));
  const burnAmt = maxLpSupply - actualSupply;
  return (burnAmt / maxLpSupply) * 100;
}

// Main function to calculate burn percentage based on token mint
async function calculateBurnPercentage(tokenMint) {
  try {
    const info = await queryLpByToken(tokenMint);

    if (!info || !info.Raydium_LiquidityPoolv4 || info.Raydium_LiquidityPoolv4.length === 0) {
      throw new Error("No pool information found.");
    }

    const lpMint = info.Raydium_LiquidityPoolv4[0].lpMint;
    const lpReserveRaw = info.Raydium_LiquidityPoolv4[0].lpReserve;

    // Get the current supply and decimals for lpMint
    const parsedAccInfo = await connection.getParsedAccountInfo(new PublicKey(lpMint));
    const mintInfo = parsedAccInfo?.value?.data?.parsed?.info;

    if (!mintInfo) {
      throw new Error("Failed to fetch mint info.");
    }

    const decimals = mintInfo.decimals;
    const lpReserve = lpReserveRaw / Math.pow(10, decimals);
    const actualSupply = mintInfo.supply / Math.pow(10, decimals);

    // Calculate burn percentage
    const burnPercentage = getBurnPercentage(lpReserve, actualSupply);
    return burnPercentage.toFixed(2);  // Return as percentage with 2 decimal places
  } catch (error) {
    console.error("Error calculating burn percentage:", error);
    throw error;
  }
}

module.exports = {
  queryLpByToken,
  calculateBurnPercentage
};
