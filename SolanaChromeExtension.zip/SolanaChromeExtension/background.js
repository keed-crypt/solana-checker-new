
// No background script functionality is needed at the moment.
